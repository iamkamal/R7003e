close all;
clear all;
clc;

fSamplingPeriod = 0.01;

