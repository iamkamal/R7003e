close all;
clear all;
clc;

% select the sampling time
fSamplingPeriod = 0.005;

Kd = [-4.9231  -39.1276  -52.9308   -9.5343];

